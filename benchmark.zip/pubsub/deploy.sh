#!/bin/bash
scp *.py root@testmaster:/root/pubsub