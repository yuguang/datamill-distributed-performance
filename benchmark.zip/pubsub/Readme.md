Running the pub sub server
--------------------------
1. copy the pubsub folder to testmaster by running deploy.sh
2. start the redis server on testmaster

    redis-server --port 8080
    
3. run python pub.py

The pub sub benchmark script is in test.sh
